#!/bin/sh
rm -f *.retry
